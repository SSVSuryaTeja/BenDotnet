

create table TempAgent
(
   AgentID int Identity(1,1),
   FirstName varchar(30),
   MI varchar(1),
   LastName varchar(30),
   Gender varchar(10),
   DOB DateTime, 
   SSN varchar(30),
   MaritalStatus int, 
   Address1 varchar(30),
   Address2 varchar(30),
   City varchar(30),
   State varchar(30),
   ZipCode varchar(30),
   Country varchar(30),
)

select * into master..TempAgent from sqlpractice..TempAgent

select * from tempagent



Create Table AgentC
(
  AgentID int identity(1,1) primary key,
  FirstName varchar(30),
   MI varchar(1),
   LastName varchar(30),
   Gender varchar(10),
   DOB DateTime, 
   SSN varchar(30),
   MaritalStatus int, 
   Address1 varchar(30),
   Address2 varchar(30),
   City varchar(30),
   State varchar(30),
   ZipCode varchar(30),
   Country varchar(30),
)
create TABLE Error
(AgentID int,
ErrorMsg varchar(250),
ColumnName varchar(250)
)



/* function for checking firstname */

create function fnFirstNameValidate
(@FirstName varchar(15)) returns int
as
begin
  declare @ret int 
  if (@FirstName is null or len(@FirstName) > 50 
  or @FirstName like '%[^a-zA-Z]%')
	set @ret=0
  else  
   set @ret=1
  return @ret
end  


/* function for checking middle initial */   

create function fnMIValidate
(@MI varchar(15)) returns int
as
begin
  declare @ret int 
  if (@MI is null or len(@MI) > 50 
  or @MI like '%[^a-zA-Z]%')
	set @ret=0
  else  
   set @ret=1
  return @ret
end

/* function for checking lastname */

create function fnLastNameValidate
(@LastName varchar(15)) returns int
as
begin
  declare @ret int 
  if (@LastName is null or len(@LastName) > 50 
  or @LastName like '%[^a-zA-Z]%')
	set @ret=0
  else  
   set @ret=1
  return @ret
end

/* function for checking gender */

create function fnGenderValidate
(@Gender varchar(15)) returns int
as
begin
  declare @ret int 
  if (@Gender is null or len(@Gender) > 50 
  or (@Gender not like 'male' and @Gender not like 'female'))
	set @ret=0
  else  
   set @ret=1
  return @ret
end

/* function for checking DOB */


create function fndobValidate
(@dob varchar(20)) returns int
as
begin
  declare @ret int
  if (@dob is null or @dob>getdate())
    set @ret=0
  else
    set @ret=1
  return @ret
end

/* function for checking SSN */

create function fnSSNValidate(@SSN varchar(20))
returns int 
as
begin
   declare @ret int
   if @ssn NOT LIKE 
'[0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]'
   set @ret=0
   else
   set @ret=1
   return @ret
end 

/* function for checking MaritalStatus */

create function fnMaritalStatusValidate(@MaritalStatus varchar(20))
returns int 
as
begin
   declare @ret int
   if  @MaritalStatus  IS NULL or 
(@MaritalStatus not like '0' and @MaritalStatus  not like '1')
   set @ret=0
   else
   set @ret=1
   return @ret
end 

/* procedure using functions */
create Proc PrcAgentTrf 
as
  Insert into Error(AgentID,ErrorMsg,ColumnName)
   select AgentID,'First Name is not Correct',
	'FirstName' from TempAgent where 
     dbo.fnFirstNameValidate(FirstName)=0

 Insert into Error(AgentID,ErrorMsg,ColumnName)
   select AgentID,'Middle Initial is not Correct',
	'MI' from TempAgent where 
     dbo.fnMIValidate(MI)=0

 Insert into Error(AgentID,ErrorMsg,ColumnName)
   select AgentID,'Last Name is not Correct',
	'LastName' from TempAgent where 
     dbo.fnLastNameValidate(LastName)=0

Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentID,'Gender is not Correct',
	'Gender' from TempAgent where 
  dbo.fnGenderValidate(Gender)=0

Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentID,'DOB is not Correct',
	'DOB' from TempAgent where 
     dbo.fndobValidate(dob)=0

Insert into Error(AgentID,ErrorMsg,ColumnName)
   select AgentID,'SSN is Not Proper Format',
    'SSN'from TempAgent where 
      dbo.fnSSNValidate(SSN)=0

Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentID,'MaritalStatus  is not Correct',
	'MaritalStatus ' from TempAgent where 
        dbo.fnMaritalStatusValidate(MaritalStatus)=0

    Insert into AgentC(FirstName,MI,LastName,Gender,DOB,SSN,MaritalStatus,Address1,Address2,City,State,Zipcode,Country) 
   select FirstName,MI,LastName,Gender,DOB,SSN,MaritalStatus,Address1,Address2,City,State,Zipcode,Country from TempAgent 
   where AgentID <> all(Select AgentID from Error) and gender in('male','female')



create clustered index Error_er on
Error(AgentID)


select * from error
select * from agentc