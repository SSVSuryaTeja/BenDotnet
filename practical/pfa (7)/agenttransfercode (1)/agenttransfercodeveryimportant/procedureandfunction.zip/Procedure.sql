create table TempAgent
(
   AgentID int Identity(1,1),
   FirstName varchar(30),
   MI varchar(1),
   LastName varchar(30),
   Gender varchar(10),
   DOB DateTime, 
   SSN varchar(30),
   MaritalStatus int, 
   Address1 varchar(30),
   Address2 varchar(30),
   City varchar(30),
   State varchar(30),
   ZipCode varchar(30),
   Country varchar(30),
)


Create Table AgentC
(
  AgentID int identity(1,1) primary key,
  FirstName varchar(30),
   MI varchar(1),
   LastName varchar(30),
   Gender varchar(10),
   DOB DateTime, 
   SSN varchar(30),
   MaritalStatus int, 
   Address1 varchar(30),
   Address2 varchar(30),
   City varchar(30),
   State varchar(30),
   ZipCode varchar(30),
   Country varchar(30),
)
create TABLE Error
(AgentID int,
ErrorMsg varchar(250),
ColumnName varchar(250)
)


create clustered index Error_er on
Error(AgentID)



create Proc PrcAgentCheck 
as
   Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentId,'First Name is not Correct',
	'FirstName' from TempAgent where 
    firstname IS NULL or 
LEN(firstname)>50 or 
firstname  LIKE '%[^a-zA-Z]%' 

Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentID,'Middle Initial is not Correct',
	'MI' from TempAgent where 
    MI IS NULL or 
LEN(MI)>50 or 
MI LIKE '%[^a-zA-Z]%' 

Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentID,'Last Name is not Correct',
	'LastName' from TempAgent where 
    lastname IS NULL or 
LEN(lastname)>50 or 
lastname  LIKE '%[^a-zA-Z]%' 

Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentID,'Gender is not Correct',
	'Gender' from TempAgent where 
    Gender IS NULL or 
(gender not like 'male' and gender not like 'female')

Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentID,'DOB is not Correct',
	'DOB' from TempAgent where 
    DOB IS NULL or 
   DOB>getdate()

   Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentID,'SSN is Not Proper Format','SSN'
        from TempAgent where
	ssn is null or ssn  
	NOT LIKE 
'[0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]' 

Insert into Error(AgentId,ErrorMsg,ColumnName)
   select AgentID,'MaritalStatus  is not Correct',
	'MaritalStatus ' from TempAgent where 
    MaritalStatus  IS NULL or 
(MaritalStatus not like '0' and MaritalStatus  not like '1')

  Insert into AgentC(FirstName,MI,LastName,Gender,DOB,SSN,MaritalStatus,Address1,Address2,City,State,Zipcode,Country) 
   select FirstName,MI,LastName,Gender,DOB,SSN,MaritalStatus,Address1,Address2,City,State,Zipcode,Country from TempAgent 
   where AgentID <> all(Select AgentID from Error) and gender in('male','female')

select * from tempagent

PrcAgentCheck

select * from Agent
select * from Error
select * from AgentC


